## References
- https://pkg.go.dev/net/http
- https://pkg.go.dev/log
- https://www.restapitutorial.com/lessons/httpmethods.html
- https://pkg.go.dev/sync#RWMutex.RLock
- https://regex101.com/
- https://pkg.go.dev/regexp#Regexp.FindStringSubmatch
- https://pkg.go.dev/time
- https://en.wikipedia.org/wiki/Unix_time
- https://pkg.go.dev/encoding/json#Marshaler
- https://pkg.go.dev/encoding/json#Unmarshaler
- https://pkg.go.dev/encoding/json#example-package-CustomMarshalJSON
- https://golangbyexample.com/parse-unix-timestamp-time-go/
- http://choly.ca/post/go-json-marshalling/
- https://pkg.go.dev/testing
- https://pkg.go.dev/net/url

### Modularize Go application on private GitHub repository
- https://stackoverflow.com/a/65852935 (=> https://github.com/settings/tokens)
    - `~/.netrc`: `mashine github.com/litec-thesis/2223-thesis-5abhit-zoecbe_mayrjo_grupa-cardstorage MayrJo170211 <token>`
- https://stackoverflow.com/a/55302537
- `go get github.com/litec-thesis/2223-thesis-5abhit-zoecbe_mayrjo_grupa-cardstorage/src/api@golang_Api`

### Disable `go get` fetching remote changes instead local changes only
- `go mod edit -replace github.com/litec-thesis/2223-thesis-5abhit-zoecbe_mayrjo_grupa-cardstorage/src/api=./api/`
- `go mod edit -replace github.com/litec-thesis/2223-thesis-5abhit-zoecbe_mayrjo_grupa-cardstorage/src/api/logger=./api/logger/`
- `go mod tidy`

### Tools
- https://json-generator.com/
- https://extendsclass.com/json-generator.html
- https://hub.docker.com/r/keinos/sqlite3
- https://www.sqlservertutorial.net/sql-server-sample-database/

## Run
```sh
$ chmod +x run && ./run
```

### Environment
```sh
$ export API_IP=[localhost]
$ export API_PORT=[7171]
```

## Dependencies
### Docker
- `$ docker pull keinos/sqlite3`
### Go
- `go version go1.18.4 linux/amd64`

### Project Setup
```sh
$ go mod init github.com/litec-thesis/2223-thesis-5abhit-zoecbe_mayrjo_grupa-cardstorage/api
$ go mod tidy
```