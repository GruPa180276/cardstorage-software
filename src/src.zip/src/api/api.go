package api

import (
	"database/sql"
	"fmt"
	"net/http"
	"sync"

	"github.com/litec-thesis/2223-thesis-5abhit-zoecbe_mayrjo_grupa-cardstorage/src/api/logger"
	_ "github.com/mattn/go-sqlite3"
)

var L, Lfatal logger.LoggerFunc

func NewHandler(l, lfatal logger.LoggerFunc, dbName string) *http.ServeMux {
	L = l
	Lfatal = lfatal

	var mux *http.ServeMux = http.NewServeMux()
	var guard *sync.RWMutex = &sync.RWMutex{}

	var db *sql.DB
	var err error

	db, err = sql.Open("sqlite3", fmt.Sprintf("file:%s", dbName))
	if err != nil {
		Lfatal("Could not open database connection: %s\n", err.Error())
	}
	L("Sucessfully opened DB connection")

	if err := CreateCardsIfNotExists(db); err != nil {
		Lfatal("Could not create database model: %s", err.Error())
	}
	if err := CreateStorageUnitsIfNotExists(db); err != nil {
		Lfatal("Could not create database model: %s", err.Error())
	}
	if err := CreateUsersIfNotExists(db); err != nil {
		Lfatal("Could not create database model: %s", err.Error())
	}
	L("Successfully created DB model")

	if err := DeleteSampleData(db, guard); err != nil {
		Lfatal("Could not delete data: %s", err)
	}
	L("Successfully deleted remaining sample data")

	if err := InsertSampleData(db, guard); err != nil {
		Lfatal("Could not insert data: %s", err.Error())
	}
	L("Successfully inserted sample data")

	var rootHandler *RootHandler = NewRootHandler()
	var cardHandler *CardHandler = NewCardHandler(NewCardDatastore(db, guard))
	var storageHandler *StorageHandler = NewStorageHandler(NewStorageDatastore(db, guard))
	var userHandler *UserHandler = NewUserHandler(NewUserDatastore(db, guard))

	mux.Handle("/", rootHandler)
	mux.Handle("/card", cardHandler)
	mux.Handle("/card/", cardHandler)
	mux.Handle("/storage", storageHandler)
	mux.Handle("/storage/", storageHandler)
	mux.Handle("/user", userHandler)
	mux.Handle("/user/", userHandler)

	L("Registered HTTP Handlers")

	return mux
}
