package api

import (
	"bytes"
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"sync"
	"time"
)

type CardId_t int

type Card struct {
	Id            CardId_t    `json:"id"`
	Name          string      `json:"name"`
	StorageId     StorageId_t `json:"storageId"`
	IsAvailable   bool        `json:"isAvailable"`
	IsReserved    bool        `json:"isReserved"`
	ReservedSince time.Time   `json:"reservedSince"`
	ReservedUntil time.Time   `json:"reservedUntil"`
}

// ctor
func NewCard() *Card {
	return &Card{}
}

// Correctly convert UNIX Timestamp into Go's time.Time type
func (self *Card) UnmarshalJSON(data []byte) error /* implements json.Unmarshaler */ {
	// convert byte-stream into generic adressable type
	// strongly type to make sure go's reflection knows
	var d interface{}
	err := json.Unmarshal(data, &d)

	if err != nil {
		max_bytes_to_log := 100
		if len(data) < max_bytes_to_log {
			max_bytes_to_log = len(data)
		}
		L("Error parsing JSON: '%s'\n", string(data[:max_bytes_to_log]))
		return err
	}

	card := d.(map[string]interface{})

	for k, v := range card {
		switch k {
		case "id":
			self.Id = CardId_t(v.(float64)) // in JSON, numbers are by default floating point
		case "name":
			self.Name = v.(string)
		case "storageId":
			self.StorageId = StorageId_t(v.(float64))
		case "isAvailable":
			self.IsAvailable = v.(bool)
		case "isReserved":
			self.IsReserved = v.(bool)
		case "reservedSince":
			self.ReservedSince = time.Unix(int64(v.(float64)), 0)
		case "reservedUntil":
			self.ReservedUntil = time.Unix(int64(v.(float64)), 0)
		default:
			return fmt.Errorf("Error during parsing: unknown key '%s'", k)
		}
	}

	return nil
}

// Correctly convert Go's time.Time type into UNIX Timestamp
func (self *Card) MarshalJSON() ([]byte, error) /* implements json.Marshaler */ {
	type Alias Card
	return json.Marshal(&struct {
		*Alias
		ReservedSince int64 `json:"reservedSince"`
		ReservedUntil int64 `json:"reservedUntil"`
	}{
		Alias:         (*Alias)(self),
		ReservedSince: self.ReservedSince.Unix(),
		ReservedUntil: self.ReservedUntil.Unix(),
	})
}

func (self *Card) String() string /* implements fmt.Stringer */ {
	return fmt.Sprintf("Card@%p{Id:%v, Name:%v, StorageId:%v, IsAvailable:%v, IsReserved:%v, ReservedSince:%v, ReservedUntil:%v}",
		self,
		self.Id,
		self.Name,
		self.StorageId,
		self.IsAvailable,
		self.IsReserved,
		self.ReservedSince,
		self.ReservedUntil,
	)
}

type CardDatastore struct {
	*sql.DB
	*sync.RWMutex
}

// ctor
func NewCardDatastore(db *sql.DB, guard *sync.RWMutex) *CardDatastore {
	return &CardDatastore{DB: db, RWMutex: guard}
}

type CardHandler struct {
	Datastore *CardDatastore
}

// ctor
func NewCardHandler(datastore *CardDatastore) *CardHandler {
	return &CardHandler{Datastore: datastore}
}

var (
	matcherGetAllCards = Routes["card"][0]
	matcherGetCardById = Routes["card"][1]
)

// /card Multiplexer
func (self *CardHandler) ServeHTTP(res http.ResponseWriter, req *http.Request) /* implements http.HandlerFunc */ {
	L("CardHandler :: URL: '%s', URL Path: '%s', Method: %s", req.URL.String(), req.URL.Path, req.Method)

	// basic CRUD operations
	// GET for reading cards
	// 		- get card by id: "/card/{id}"
	//      - get all cards:  "/card"
	// POST for creating cards
	// PUT for updating cards
	// DELETE for removing cards
	res.Header().Set("content-type", "application/json")

	// check content length
	if req.ContentLength > CFG_MAX_CONTENT_LENGTH {
		L("Error: Content-Length exceeded by %d byte(s)", req.ContentLength-CFG_MAX_CONTENT_LENGTH)
		Writef(&res, http.StatusBadRequest, `{"error": "Content-Length exceeded by %d byte(s)"}`, req.ContentLength-CFG_MAX_CONTENT_LENGTH)
		return
	}

	switch {
	case http.MethodGet == req.Method && matcherGetAllCards.MatchString(req.URL.Path):
		self.GetAllCards(res, req)
	case http.MethodGet == req.Method && matcherGetCardById.MatchString(req.URL.Path):
		self.GetCardById(res, req)
	case http.MethodPost == req.Method && matcherGetAllCards.MatchString(req.URL.Path):
		self.PostCard(res, req)
	case http.MethodPut == req.Method && matcherGetAllCards.MatchString(req.URL.Path):
		self.PutCard(res, req)
	case http.MethodDelete == req.Method && matcherGetCardById.MatchString(req.URL.Path):
		self.DeleteCard(res, req)
	default:
		L("CardHandler :: Error: Requested resource is currently not available: %s%s", req.Method, req.URL.Path)
		Writef(&res, http.StatusNotFound, `{"error": "Requested resource is currently not available: %s%s"}`, req.Method, req.URL.Path)
	}
}

// respond with all available cards as JSON
func (self *CardHandler) GetAllCards(res http.ResponseWriter, req *http.Request) {
	cards, err := self.Datastore.SelectAll()
	if err != nil {
		L("GET /card: GetAllCards: Error during database request: %s", err.Error())
		Writef(&res, http.StatusInternalServerError, `{"error": "Error during database request: %s"}`, err.Error())
		return
	}

	if stream, err := json.Marshal(cards); err == nil {
		WriteBytes(&res, http.StatusOK, stream)
		return
	} else {
		L("GET /card: GetAllCards: Error during serialization: %s", err.Error())
		Writef(&res, http.StatusBadRequest, `{"error": "Error during serialization: %s"}`, err.Error())
	}
}

func (self *CardHandler) GetCardById(res http.ResponseWriter, req *http.Request) {
	id, err := strconv.Atoi(matcherGetCardById.FindStringSubmatch(req.URL.Path)[1])
	if err != nil {
		L("GET: GetCardById: Error during conversion of request URL(%s): %s", req.URL.Path, err)
		return
	}

	card, err := self.Datastore.Select(id)
	nonexistent := err == sql.ErrNoRows
	if nonexistent {
		L("GET: GetCardById(#%d): Does not exist: %s", id, err.Error())
		Write(&res, http.StatusNotFound, "{}")
		return
	}
	if err != nil {
		L("GET: GetCardById(#%d): Error during database request: %s", id, err.Error())
		Writef(&res, http.StatusInternalServerError, `{"error": "Error during database request: %s"}`, err.Error())
		return
	}

	var buffer *bytes.Buffer = new(bytes.Buffer)
	var encoder *json.Encoder = json.NewEncoder(buffer)
	err = encoder.Encode(card)
	if err != nil {
		L("GET /card: GetCardById(#%d): Error during serialization: %s", id, err.Error())
		Writef(&res, http.StatusBadRequest, `{"error": "Error during serialization of (%s): %s"}`, card.String(), err.Error())
		return
	}

	WriteBytes(&res, http.StatusOK, buffer.Bytes())
}

func (self *CardHandler) PostCard(res http.ResponseWriter, req *http.Request) {
	var decoder *json.Decoder = json.NewDecoder(req.Body)

	card := Card{}
	if err := decoder.Decode(&card); err != nil {
		res.WriteHeader(http.StatusBadRequest)
		res.Write([]byte(fmt.Sprintf(`{"error": "Invalid Format: %s"}`, err.Error())))

		return
	}

	c, err := self.Datastore.Select(int(card.Id))
	if c != nil {
		res.WriteHeader(http.StatusBadRequest)
		res.Write([]byte(fmt.Sprintf(`{"error": "Card #%v already exists! Use PUT to update it!"}`, card.Id)))

		return
	}

	if err != nil && err != sql.ErrNoRows {
		res.WriteHeader(http.StatusInternalServerError)
		res.Write([]byte(fmt.Sprintf(`{"error": "Error during database request: %s"}`, err.Error())))

		return
	}

	_, err = self.Datastore.Insert(&card) // handle errors (Constraint violation etc.)
	if err != nil {
		L("Insert: Error:", err.Error())
	}
}

func (self *CardHandler) PutCard(res http.ResponseWriter, req *http.Request) {
	var decoder *json.Decoder = json.NewDecoder(req.Body)

	var card Card = Card{}
	if err := decoder.Decode(&card); err != nil {
		Writef(&res, http.StatusBadRequest, `{"error": "Invalid Format: %s"}`, err.Error())

		return
	}

	c, err := self.Datastore.Select(int(card.Id))
	if c == nil {
		Writef(&res, http.StatusBadRequest, `{"error": "Card #%v does not exist! Use POST to create it!"}`, card.Id)

		return
	}

	if err != nil && err != sql.ErrNoRows {
		Writef(&res, http.StatusInternalServerError, `{"error": "Error during database request: %s"}`, err.Error())

		return
	}

	_, _ = self.Datastore.Update(&card)
}

func (self *CardHandler) DeleteCard(res http.ResponseWriter, req *http.Request) {
	id, err := strconv.Atoi(matcherGetCardById.FindStringSubmatch(req.URL.Path)[1])
	if err != nil {
		L("DELETE: DeleteCardById: Error during conversion of request URL(%s): %s", req.URL.Path, err)

		return
	}

	c, err := self.Datastore.Select(id)
	if c == nil {
		Writef(&res, http.StatusBadRequest, `{"error": "Card #%v does not exist! Use POST to create it!"}`, id)
		L("DELETE: DeleteCardById(%d): Trying to delete non-existent card!", id)

		return
	}

	if err != nil && err != sql.ErrNoRows {
		Writef(&res, http.StatusInternalServerError, `{"error": "Error during database request: %s"}`, err.Error())
		L("DELETE: DeleteCardById(%d): Error during database request: %s", id, err)

		return
	}

	_, _ = self.Datastore.Delete(id)
}

func (self *CardDatastore) Select(id int) (*Card, error) {
	c := Card{}

	var reservedSince, reservedUntil int64

	self.RLock()
	err := self.QueryRow(`SELECT id, cardName, storageId, isAvailable, isReserved, reservedSince, reservedUntil FROM Cards WHERE id = ?`, id).Scan(
		&c.Id,
		&c.Name,
		&c.StorageId,
		&c.IsAvailable,
		&c.IsReserved,
		&reservedSince,
		&reservedUntil,
	)
	self.RUnlock()

	c.ReservedSince = time.Unix(reservedSince, 0)
	c.ReservedUntil = time.Unix(reservedUntil, 0)

	if err != nil {
		return nil, err
	}

	return &c, nil
}

func (self *CardDatastore) SelectAll() ([]Card, error) {
	self.RLock()
	rows, err := self.Query(`SELECT id, cardName, storageId, isAvailable, isReserved, reservedSince, reservedUntil FROM Cards`)
	self.RUnlock()

	if err != nil {
		return nil, err
	}

	var cards []Card = make([]Card, 0)
	var reservedSince, reservedUntil int64

	for rows.Next() {
		c := Card{}

		err := rows.Scan(&c.Id, &c.Name, &c.StorageId, &c.IsAvailable, &c.IsReserved, &reservedSince, &reservedUntil)
		if err != nil {
			return nil, err
		}

		c.ReservedSince = time.Unix(reservedSince, 0)
		c.ReservedUntil = time.Unix(reservedUntil, 0)

		cards = append(cards, c)
	}

	return cards, nil
}

func (self *CardDatastore) Insert(card *Card) (result sql.Result, err error) {
	if card == nil {
		return nil, NullReferenceError
	}

	self.Lock()
	result, err = self.Exec(`INSERT INTO Cards (id, cardName, storageId, isAvailable, isReserved, reservedSince, reservedUntil) VALUES (?,?,?,?,?,?,?);`,
		card.Id,
		card.Name,
		card.StorageId,
		card.IsAvailable,
		card.IsReserved,
		card.ReservedSince.Unix(),
		card.ReservedUntil.Unix(),
	)
	self.Unlock()

	return
}

func (self *CardDatastore) Update(card *Card) (result sql.Result, err error) {
	if card == nil {
		return nil, NullReferenceError
	}

	self.Lock()
	result, err = self.Exec(`
	UPDATE Cards SET 
	cardName = ?, 
	storageId = ?, 
	isAvailable = ?, 
	isReserved = ?, 
	reservedSince = ?, 
	reservedUntil = ?
	WHERE id = ?; 
	`,
		card.Name,
		card.StorageId,
		card.IsAvailable,
		card.IsReserved,
		card.ReservedSince.Unix(),
		card.ReservedUntil.Unix(),
		card.Id,
	)
	self.Unlock()

	return
}

func (self *CardDatastore) Delete(id int) (result sql.Result, err error) {
	self.Lock()
	result, err = self.Exec(`DELETE FROM Cards WHERE id = ?`, id)
	self.Unlock()
	return
}
