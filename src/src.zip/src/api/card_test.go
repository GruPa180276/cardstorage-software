package api

import "testing"

func TestMain(m *testing.M) {
	// setup
	m.Run() // run all the tests
	// teardown
}

func cleanupDatabaseAfterEachTest() {

}

func TestCard_GetAllCards(t *testing.T) {
	t.Cleanup(cleanupDatabaseAfterEachTest)
}

func TestCard_GetCardsById_CorrectId(t *testing.T) {

}

func TestCard_GetCardsById_NonExistentId(t *testing.T) {

}

func TestCard_PostCard_CorrectKeyNamesAndValues(t *testing.T) {

}

func TestCard_PostCard_CorrectKeyNamesIncorrectValueTypes(t *testing.T) {

}

func TestCard_PostCard_IncorrectKeyNames(t *testing.T) {

}

func TestCard_PostCard_EmptyCreate(t *testing.T) {

}

func TestCard_PutCard_UpdateValidCard(t *testing.T) {

}

func TestCard_PutCard_UpdateNonExistentCard(t *testing.T) {

}

func TestCard_PutCard_EmptyUpdate(t *testing.T) {

}

func TestCard_DeleteCard_DeleteValidCard(t *testing.T) {

}

func TestCard_DeleteCard_DeleteNonExistantCard(t *testing.T) {

}
