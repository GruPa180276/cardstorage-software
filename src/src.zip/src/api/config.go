package api

const (
	CFG_MAX_CONTENT_LENGTH int64 = 1 << 10
)
