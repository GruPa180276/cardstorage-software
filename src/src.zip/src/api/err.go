package api

import "fmt"

var NullReferenceError error = fmt.Errorf("NullReferenceError")
