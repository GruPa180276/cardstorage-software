package api

import (
	"fmt"
	"net/http"
)

func WriteBytes(res *http.ResponseWriter, code int, message []byte) error {
	if res == nil {
		return NullReferenceError
	}

	(*res).WriteHeader(code)
	_, err := (*res).Write(message)
	return err
}

func Write(res *http.ResponseWriter, code int, message string) error {
	return WriteBytes(res, code, []byte(message))
}

func Writef(res *http.ResponseWriter, code int, format string, args ...interface{}) error {
	return Write(res, code, fmt.Sprintf(format, args...))
}
