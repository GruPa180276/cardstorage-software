package logger

import (
	"fmt"
	"log"
	"os"
	"strings"
)

type LoggerFunc func(interface{}, ...interface{})

func NewLoggerShortcut(logger *log.Logger) (Logger LoggerFunc, LoggerFatal LoggerFunc) {
	Logger = func(object interface{}, args ...interface{}) {
		if len(args) > 0 {
			// basic check if the first argument is a format string if it is a string
			if format, ok := object.(string); ok && strings.Contains(format, "%") {
				logger.Printf(format, args...)
				return
			} else {
				// arguments are sperated by space regardless of type
				s := fmt.Sprint(object)
				for _, arg := range args {
					s += " " + fmt.Sprint(arg)
				}
				logger.Print(s)

				return
			}
		}
		logger.Print(object)
	}

	LoggerFatal = func(object interface{}, args ...interface{}) {
		Logger(object, args)
		os.Exit(1)
	}

	return
}
