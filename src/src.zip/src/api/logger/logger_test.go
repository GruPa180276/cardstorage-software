package logger

import (
	"bytes"
	"log"
	"testing"

	"github.com/stretchr/testify/assert"
)

var buffer *bytes.Buffer = new(bytes.Buffer)
var logger *log.Logger = log.New(buffer, "", 0x00)
var L, _ LoggerFunc = NewLoggerShortcut(logger)

func TestMain(m *testing.M) {
	buffer.Reset()
	m.Run()
}

func TestLoggerWithSingleStringArgument(t *testing.T) {
	t.Cleanup(buffer.Reset)

	L("hello!")
	assert.True(t, buffer.String() == "hello!\n")

	buffer.Reset()

	L("bye!")
	assert.True(t, buffer.String() == "bye!\n")

	buffer.Reset()

	L(true)
	assert.True(t, buffer.String() == "true\n")
}

func TestLoggerWithArgsOfDifferentType(t *testing.T) {
	t.Cleanup(buffer.Reset)

	L("hello", 1, 3.14, "bye!")
	assert.True(t, buffer.String() == "hello 1 3.14 bye!\n")

	buffer.Reset()

	L(true, 42, "whatever ", 2.717, true, false)
	assert.True(t, buffer.String() == "true 42 whatever  2.717 true false\n")
}

func TestLoggerWithFormatStringAndCorrespondingArgs(t *testing.T) {
	t.Cleanup(buffer.Reset)

	L("Hello from %s! Welcome to the %v. We're living in the %dth century!", "Mars", "future", 23)
	assert.True(t, buffer.String() == "Hello from Mars! Welcome to the future. We're living in the 23th century!\n")
}

func TestLoggerWithFormatStringAndMissingArgs(t *testing.T) {
	t.Cleanup(buffer.Reset)

	L("Hello from %s! Welcome to the %v. We're living in the %dth century!", "Mars", "future")
	assert.True(t, buffer.String() == "Hello from Mars! Welcome to the future. We're living in the %!d(MISSING)th century!\n")
}
