package api

import (
	"database/sql"
	"io/ioutil"
)

func CreateCardsIfNotExists(db *sql.DB) (err error) {
	stream, err := ioutil.ReadFile("api/model/cards.sql")
	if err != nil {
		return
	}

	_, err = db.Exec(string(stream))
	return
}

func CreateStorageUnitsIfNotExists(db *sql.DB) (err error) {
	stream, err := ioutil.ReadFile("api/model/storages.sql")
	if err != nil {
		return
	}

	_, err = db.Exec(string(stream))
	return
}

func CreateUsersIfNotExists(db *sql.DB) (err error) {
	stream, err := ioutil.ReadFile("api/model/users.sql")
	if err != nil {
		return
	}

	_, err = db.Exec(string(stream))
	return
}