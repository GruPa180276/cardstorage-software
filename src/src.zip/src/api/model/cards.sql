CREATE TABLE IF NOT EXISTS Cards (
    id INTEGER PRIMARY KEY NOT NULL,
    cardName TEXT NOT NULL UNIQUE,
    storageId INTEGER NOT NULL,
    isAvailable BIT NOT NULL,
    isReserved BIT NULL,
    ReservedSince TIME NULL,                     
	ReservedUntil TIME NULL,                     
    FOREIGN KEY (storageId) REFERENCES Storages(id)
);