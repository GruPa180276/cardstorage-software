CREATE TABLE IF NOT EXISTS Storages (
    id INTEGER PRIMARY KEY NOT NULL,
    storageName TEXT NOT NULL,
    ipAddr TEXT NOT NULL,
    loc TEXT NOT NULL,
    room TEXT NOT NULL,
    capacity INTEGER NOT NULL
);
