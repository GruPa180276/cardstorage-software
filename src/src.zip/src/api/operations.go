package api

import "database/sql"

type Operations[Key, Value any] interface {
	Select(Key) (Value, error)
	SelectAll() ([]Value, error)
	Insert(Value) (sql.Result, error)
	Update(Value) (sql.Result, error)
	Delete(Key) (sql.Result, error)
}
