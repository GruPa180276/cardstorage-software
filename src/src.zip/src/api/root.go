package api

import (
	"net/http"
)

type RootHandler struct{}

// ctor
func NewRootHandler() (handler *RootHandler) {
	handler = &RootHandler{}
	return
}

func (self *RootHandler) ServeHTTP(res http.ResponseWriter, req *http.Request) {
	L("URL: '%s', Method: %s\n", req.URL.String(), req.Method)
	res.Header().Set("content-type", "text/html")
	Write(&res, http.StatusBadRequest, "<h1>Nothing to see here yet!<h1>")
}
