package api

import "regexp"

var Routes = map[string][]*regexp.Regexp{
	"card": {
		regexp.MustCompile(`^/card[/]?$`),      // get all cards
		regexp.MustCompile(`^/card/([0-9]+)$`), // get card by id
	},
	"storage": {
		regexp.MustCompile(`^/storage[/]?$`),      // get all storage units
		regexp.MustCompile(`^/storage/([0-9]+)$`), // get storage unit by id
	},
}
