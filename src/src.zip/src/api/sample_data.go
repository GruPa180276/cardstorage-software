package api

import (
	"database/sql"
	"encoding/json"
	"sync"
)

func DeleteSampleData(db *sql.DB, guard *sync.RWMutex) (err error) {
	guard.Lock()
	_, err = db.Exec("DELETE FROM Storages;")
	_, err = db.Exec("DELETE FROM Cards;")
	_, err = db.Exec("DELETE FROM Users;")
	guard.Unlock()
	return
}

func InsertSampleData(db *sql.DB, guard *sync.RWMutex) error {
	if err := insertCardSampleData(NewCardDatastore(db, guard)); err != nil {
		return err
	}

	return nil
}

func insertCardSampleData(store *CardDatastore) error {
	cards := new([]Card)
	if err := json.Unmarshal([]byte(`
	[
		{
			"id": 78,
			"name": "Card78",
			"storageId": 1117,
			"isAvailable": false,
			"isReserved": true,
			"reservedSince": 1661295124,
			"reservedUntil": 1661295145
		},
		{
			"id": 79,
			"name": "Card79",
			"storageId": 1118,
			"isAvailable": true,
			"isReserved": false,
			"reservedSince": 1010101010,
			"reservedUntil": 1010101010
		}
	]
	`), cards); err != nil {
		return err
	}

	for _, card := range *cards {
		if _, err := store.Insert(&card); err != nil {
			return err
		}
	}

	return nil
}
