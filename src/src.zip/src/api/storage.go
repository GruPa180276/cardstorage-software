package api

import (
	"database/sql"
	"net/http"
	"sync"
)

type StorageId_t int

type Storage struct {
	Id        StorageId_t `json:"id"`
	Name      string      `json:"name"`
	IpAddress string      `json:"ip"`
	Locaction string      `json:"location"`
	Room      string      `json:"room"`
	Capacity  int         `json:"capacity"`
}

type StorageDatastore struct {
	*sql.DB
	*sync.RWMutex
}

func NewStorageDatastore(db *sql.DB, guard *sync.RWMutex) *StorageDatastore {
	return &StorageDatastore{DB: db, RWMutex: guard}
}

type StorageHandler struct {
	Datastore *StorageDatastore
}

func NewStorageHandler(datastore *StorageDatastore) *StorageHandler {
	return &StorageHandler{Datastore: datastore}
}

var (
	matcherGetAllStorageUnits = Routes["storage"][0]
	matcherGetStorageUnitById = Routes["storage"][1]
)

func (self *StorageHandler) ServeHTTP(res http.ResponseWriter, req *http.Request) {
	L("StorageHandler :: URL: '%s', URL Path: '%s', Method: %s", req.URL.String(), req.URL.Path, req.Method)
	res.Header().Set("content-type", "application/json")

	// check content length
	if req.ContentLength > CFG_MAX_CONTENT_LENGTH {
		L("Error: Content-Length exceeded by %d byte(s)", req.ContentLength-CFG_MAX_CONTENT_LENGTH)
		Writef(&res, http.StatusBadRequest, `{"error": "Content-Length exceeded by %d byte(s)"}`, req.ContentLength-CFG_MAX_CONTENT_LENGTH)
		return
	}

	switch {
	case http.MethodGet == req.Method && matcherGetAllStorageUnits.MatchString(req.URL.Path):
		self.GetAllStorageUnits(res, req)
	case http.MethodGet == req.Method && matcherGetStorageUnitById.MatchString(req.URL.Path):
		self.GetStorageUnitById(res, req)
	default:
		L("StorageHandler :: Error: Requested resource is currently not available: %s%s", req.Method, req.URL.Path)
		Writef(&res, http.StatusNotFound, `{"error": "Requested resource is currently not available: %s%s"}`, req.Method, req.URL.Path)
	}
}

func (self *StorageHandler) GetAllStorageUnits(res http.ResponseWriter, req *http.Request) {

}

func (self *StorageHandler) GetStorageUnitById(res http.ResponseWriter, req *http.Request) {

}

func (self *StorageDatastore) Select(id StorageId_t) (*Storage, error) {
	s := Storage{}

	self.RLock()
	err := self.QueryRow(`SELECT id, storageName, ipAddr, loc, room, capacity FROM Storages WHERE id = ?`, id).Scan(
		&s.Id,
		&s.Name,
		&s.IpAddress,
		&s.Locaction,
		&s.Room,
		&s.Capacity,
	)
	self.RUnlock()

	if err != nil {
		return nil, err
	}

	return &s, nil
}

func (self *StorageDatastore) SelectAll() ([]Storage, error) {
	self.RLock()
	rows, err := self.Query(`SELECT id, storageName, ipAddr, loc, room, capacity FROM Storages`)
	self.RUnlock()

	if err != nil {
		return nil, err
	}

	var storages []Storage = make([]Storage, 0)

	for rows.Next() {
		s := Storage{}
		err := rows.Scan(&s.Id, &s.Name, &s.IpAddress, &s.Locaction, &s.Room, &s.Capacity)
		if err != nil {
			return nil, err
		}
		storages = append(storages, s)
	}

	return storages, nil
}
