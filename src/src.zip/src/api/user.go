package api

import (
	"database/sql"
	"net/http"
	"sync"
)

type User struct {
	// todo
}

type UserDatastore struct {
	*sql.DB
	*sync.RWMutex
}

func NewUserDatastore(db *sql.DB, guard *sync.RWMutex) *UserDatastore {
	return &UserDatastore{DB: db, RWMutex: guard}
}

type UserHandler struct {
	Datastore *UserDatastore
}

func NewUserHandler(datastore *UserDatastore) *UserHandler {
	return &UserHandler{Datastore: datastore}
}

func (self *UserHandler) ServeHTTP(res http.ResponseWriter, req *http.Request) {

}
