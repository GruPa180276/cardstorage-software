package main

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path"
	"regexp"
	"sort"
	"strconv"
	"time"

	"github.com/litec-thesis/2223-thesis-5abhit-zoecbe_mayrjo_grupa-cardstorage/src/api"
	"github.com/litec-thesis/2223-thesis-5abhit-zoecbe_mayrjo_grupa-cardstorage/src/api/logger"
)

var L logger.LoggerFunc
var Lfatal logger.LoggerFunc

var persistent *os.File
var apiLogger *log.Logger

func init() {
	initBuffer := new(bytes.Buffer)
	initL, initLfatal := logger.NewLoggerShortcut(log.New(io.MultiWriter(initBuffer), "API_EarlyInit: ", log.LstdFlags))

	initL("Initializating logger")
	latestLog := path.Join(os.Getenv("API_LOG_DIR"), fmt.Sprint(time.Now().Unix()))
	persistent, err := os.Create(latestLog)
	if err != nil {
		initLfatal(fmt.Sprintf("Early initialization failed: could not create log (%s)\n", err.Error()))
	}
	initL("Logging events in %s", latestLog)

	pathLatest := path.Join(os.Getenv("API_LOG_DIR"), "latest")
	logs, err := os.ReadDir(path.Join(os.Getenv("API_LOG_DIR")))
	timestamps := make([]int, 0)
	for _, logFile := range logs {
		if regexp.MustCompile(`^\d+$`).MatchString(logFile.Name()) {
			tsInt, err := strconv.Atoi(logFile.Name())
			if err != nil {
				continue
			}
			timestamps = append(timestamps, tsInt)
		} else if logFile.Name() == "latest" {

			if _, err := os.Lstat(pathLatest); err == nil {
				os.Remove(pathLatest)
			}
		}
	}
	sort.Ints(timestamps)
	err = os.Symlink(path.Join(os.Getenv("API_LOG_DIR"), fmt.Sprintf("%d", timestamps[len(timestamps)-1])), pathLatest)
	if err != nil {
//		panic(err)
	}
	initL("Pointing %s", pathLatest)

	var out io.Writer = io.MultiWriter(os.Stderr, persistent)
	var apiLogger *log.Logger = log.New(out, "", 0)
	L, Lfatal = logger.NewLoggerShortcut(apiLogger)

	L(initBuffer.String())

	apiLogger.SetPrefix("API: ")
	apiLogger.SetFlags(log.LstdFlags)
	L("Early initialization done")
}

func main() {
	defer persistent.Close()

	L("Listening on http://%s:%s using \"%s\" as persistent storage\n",
		os.Getenv("API_IP"),
		os.Getenv("API_PORT"),
		os.Getenv("API_DB"),
	)

	http.ListenAndServe(
		fmt.Sprintf("%s:%s", os.Getenv("API_IP"), os.Getenv("API_PORT")),
		api.NewHandler(L, Lfatal, os.Getenv("API_DB")),
	)

	recover()
}
